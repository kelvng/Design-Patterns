package bai02.lab04.dp.tdtu;

import java.util.List;

public interface SortAlg {
	public void sort(List items);
}
