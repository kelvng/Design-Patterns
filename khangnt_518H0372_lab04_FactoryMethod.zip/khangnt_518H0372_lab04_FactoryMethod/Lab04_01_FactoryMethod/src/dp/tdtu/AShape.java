package dp.tdtu;

public interface AShape {
	public double area();
}
