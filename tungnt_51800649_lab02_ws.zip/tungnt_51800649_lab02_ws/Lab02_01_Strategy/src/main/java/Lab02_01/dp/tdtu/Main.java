package Lab02_01.dp.tdtu;

public class Main {

	public static void main(String[] args) {
		StudentList test1 = DataBase.init();
		// TODO Auto-generated method stub

	}

}
