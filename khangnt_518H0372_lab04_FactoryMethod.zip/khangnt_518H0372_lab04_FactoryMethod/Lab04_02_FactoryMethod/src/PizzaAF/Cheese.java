package PizzaAF;

public interface Cheese {
	public String toString();
}
