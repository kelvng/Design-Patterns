package bai02.lab04.dp.tdtu;

import java.util.List;

public class InsertionSort implements SortAlg {

	@Override
	public void sort(List list) {
		// TODO Auto-generated method stub
		
	}

}
