package Lab02_01.dp.tdtu;

public interface ISortStrategy {
	public void sort(Comparable[] data,int count) ;
}