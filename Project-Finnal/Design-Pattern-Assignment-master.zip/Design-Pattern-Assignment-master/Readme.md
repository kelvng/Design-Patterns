#Design Pattern Assignment



![alt text](https://raw.githubusercontent.com/AaronWard/Assignment2_Design_Pattern_Report_Pandoc/master/04_assets/05_implementation/makeACake.PNG)

