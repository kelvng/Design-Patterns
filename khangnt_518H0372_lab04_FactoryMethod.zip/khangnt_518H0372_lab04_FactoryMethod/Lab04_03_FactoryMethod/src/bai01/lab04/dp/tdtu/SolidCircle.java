package bai01.lab04.dp.tdtu;

public class SolidCircle implements IShape{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Solid Circle");
	}
	
}
