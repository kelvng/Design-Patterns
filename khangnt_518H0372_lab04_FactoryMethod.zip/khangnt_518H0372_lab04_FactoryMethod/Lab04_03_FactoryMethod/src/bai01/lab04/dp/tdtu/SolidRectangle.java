package bai01.lab04.dp.tdtu;

public class SolidRectangle implements IShape{
	@Override
	public void draw(){
		System.out.println("Solid Rectangle");
	}
}
