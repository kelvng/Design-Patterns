package PizzaAF;

public interface Clams {
	public String toString();
}
