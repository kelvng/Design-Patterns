package PizzaAF;

public interface Sauce {
	public String toString();
}
