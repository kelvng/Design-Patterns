package Lab02_01.dp.tdtu;

public class SelectionSortStrategy implements ISortStrategy{
	public void sort(Comparable[] data ,int count) {
		System.out.println("SelectionSortStrategy");
	}
}
