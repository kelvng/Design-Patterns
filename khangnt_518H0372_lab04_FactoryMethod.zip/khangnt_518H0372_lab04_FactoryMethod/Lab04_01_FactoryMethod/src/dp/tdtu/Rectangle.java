package dp.tdtu;

public class Rectangle implements AShape {

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}

}
