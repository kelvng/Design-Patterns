package bai04.lab04.dp.tdtu;

import java.awt.Graphics;

public interface AShape {
	public void draw(Graphics g);
}
