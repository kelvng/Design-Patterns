package PizzaAF;

public interface Dough {
	public String toString();
}
