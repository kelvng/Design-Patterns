package Lab02_01.dp.tdtu;

public class BubbleSortStrategy implements ISortStrategy{

	public void sort(Comparable[] data, int count) {
		// TODO Auto-generated method stub
		System.out.println("BubbleSortStrategy");
	}

}
