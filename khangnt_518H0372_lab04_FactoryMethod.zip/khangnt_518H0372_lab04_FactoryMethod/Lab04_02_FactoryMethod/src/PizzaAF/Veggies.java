package PizzaAF;

public interface Veggies {
	public String toString();
}
