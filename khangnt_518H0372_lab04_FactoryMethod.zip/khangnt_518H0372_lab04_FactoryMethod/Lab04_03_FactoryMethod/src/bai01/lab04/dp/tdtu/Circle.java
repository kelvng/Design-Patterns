package bai01.lab04.dp.tdtu;

public class Circle implements IShape{
	private double radius;
	public final double PI = 3.14;
	
	public Circle() {
		
	}
	
	public Circle(double radius) {
		this.radius = radius;
	}
	
	public double area() {
		return PI + this.radius * this.radius;
	}
	
	@Override
	public void draw() {
		System.out.print("Circle");
	}
}
