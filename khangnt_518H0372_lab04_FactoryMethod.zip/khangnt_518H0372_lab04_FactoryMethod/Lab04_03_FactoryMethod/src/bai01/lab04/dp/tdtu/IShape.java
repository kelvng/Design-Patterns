package bai01.lab04.dp.tdtu;

public interface IShape {
	void draw();
}
