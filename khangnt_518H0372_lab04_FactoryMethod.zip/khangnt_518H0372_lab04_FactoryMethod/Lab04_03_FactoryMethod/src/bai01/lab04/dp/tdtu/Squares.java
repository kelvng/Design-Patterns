package bai01.lab04.dp.tdtu;

public class Squares implements IShape{
	
	@Override
	public void draw() {
		System.out.print("Squares");
	}
}
